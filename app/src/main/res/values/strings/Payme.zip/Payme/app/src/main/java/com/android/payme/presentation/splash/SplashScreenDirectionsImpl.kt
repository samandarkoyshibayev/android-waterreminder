package com.android.payme.presentation.splash

import com.android.payme.presentation.login.LoginScreen
import com.android.payme.ui.navigation.AppNavigator
import com.android.presentation.feature.splash.SplashScreenDirections
import javax.inject.Inject

class SplashScreenDirectionsImpl @Inject constructor(
    private val appNavigator: AppNavigator
) : SplashScreenDirections{
    override suspend fun navigateToLoginScreen() {
        appNavigator.replace(LoginScreen())
    }

    override suspend fun navigateToMainScreen() {
    }
}