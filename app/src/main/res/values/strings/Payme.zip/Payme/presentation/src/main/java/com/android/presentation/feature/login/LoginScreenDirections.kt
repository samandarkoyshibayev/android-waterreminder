package com.android.presentation.feature.login

interface LoginScreenDirections {
    suspend fun navigateToOTPVerification()
}