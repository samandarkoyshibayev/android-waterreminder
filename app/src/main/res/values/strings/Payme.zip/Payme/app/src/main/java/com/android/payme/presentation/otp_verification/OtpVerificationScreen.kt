package com.android.payme.presentation.otp_verification

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.hilt.getViewModel
import com.android.payme.R
import com.android.payme.ui.component.ConfirmButtonComponent
import com.android.payme.ui.component.OtpCodeComponent
import com.android.payme.ui.theme.PaymeTheme
import com.android.payme.ui.theme.inter_semibold
import com.android.presentation.feature.login.LoginScreenViewModel
import com.android.presentation.feature.login.LoginScreenViewModelContract
import com.android.presentation.feature.opt_verification.OtpVerificationScreenViewModel
import com.android.presentation.feature.opt_verification.OtpVerificationScreenViewModelContract
import org.orbitmvi.orbit.compose.collectAsState

class OtpVerificationScreen : Screen {
    @Composable
    override fun Content() {
        val viewModel: OtpVerificationScreenViewModelContract.ViewModel = getViewModel<OtpVerificationScreenViewModel>()
        val uiState = viewModel.collectAsState().value
        OtpVerificationScreenContent(
            uiState = uiState,
            onEventDispatcher = viewModel::onEventDispatcher
        )
    }
}

@Composable
private fun OtpVerificationScreenContent(
    uiState: OtpVerificationScreenViewModelContract.UIState,
    onEventDispatcher: (OtpVerificationScreenViewModelContract.Intent) -> Unit = {}
) {
    Scaffold(
        contentColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            ConfirmButtonComponent(
                text = "Continue",
                clickListener = { onEventDispatcher(OtpVerificationScreenViewModelContract.Intent.NavigateToPinCodeScreen) },
                isEnable = true,
                isLoading = false,
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .imePadding()
                    .navigationBarsPadding()
            )
        }
    ) { paddingValues ->
        Column(modifier = Modifier
            .padding(paddingValues)
            .padding(horizontal = 16.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.ic_arrow_back),
                contentDescription = null,
                modifier = Modifier
                    .padding(top = 16.dp)
                    .size(30.dp),
            )

            Text(
                modifier = Modifier.padding(top = 28.dp),
                text = "Enter code from SMS",
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontFamily= inter_semibold
                )
            )

            Text(
                modifier = Modifier.padding(top = 16.dp),
                text = "Sent to your +99890*****58 number for confirmation",
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSecondary,
                )
            )

            Box(
                modifier = Modifier
                    .padding(top = 60.dp)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ){
                OtpCodeComponent(
                    modifier = Modifier,
                    errorState = null,
                    onErrorCleared = {},
                    onReadyListener = {}
                ){
                }
            }

            Box(
                modifier = Modifier
                    .padding(top = 40.dp)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ){
                Text(
                    modifier = Modifier.padding(top = 28.dp),
                    text = "Resend code after 00:59",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontFamily= inter_semibold
                    )
                )
            }
        }
    }
}

/*
@Preview(showBackground = true)
@Composable
private fun OtpVerificationScreenContentPreview() {
    PaymeTheme {
        OtpVerificationScreenContent()
    }
}*/
