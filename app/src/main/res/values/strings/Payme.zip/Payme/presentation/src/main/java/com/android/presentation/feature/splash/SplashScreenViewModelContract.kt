package com.android.presentation.feature.splash

class SplashScreenViewModelContract {
}