package com.android.payme.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf


@Composable
fun PaymeTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        darkTheme -> LightColorScheme
        else -> LightColorScheme
    }
    val extendedColors = LightExtendedColors

    CompositionLocalProvider(
        LocalExtendedColors provides extendedColors,
        LocalAppSpacing provides AppSpacing,
        LocalAppShapes provides AppShapes
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

val LocalExtendedColors = compositionLocalOf { LightExtendedColors }
val LocalAppSpacing = compositionLocalOf { AppSpacing }
val LocalAppShapes = compositionLocalOf { AppShapes }