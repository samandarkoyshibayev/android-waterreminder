package com.android.domain

class TestClass {
}