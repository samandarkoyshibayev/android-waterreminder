package com.android.presentation.feature.splash

interface SplashScreenDirections {

    suspend fun navigateToLoginScreen()

    suspend fun navigateToMainScreen()
}