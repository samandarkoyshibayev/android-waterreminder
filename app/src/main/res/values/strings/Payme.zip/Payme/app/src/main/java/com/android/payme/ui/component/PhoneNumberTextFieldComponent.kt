package com.android.payme.ui.component

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.android.payme.R
import com.android.payme.ui.theme.PaymeTheme
import com.android.payme.ui.theme.primaryTextColor
import com.android.payme.ui.theme.secondaryTextColor2
import com.android.payme.ui.theme.white
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.input.pointer.pointerInput
import com.android.payme.ui.theme.extendedColors

@Composable
fun PhoneNumberTextFieldComponent(
    placeholder: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    onFocusChange: (Boolean) -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    var textFieldValue by remember(value) {
        mutableStateOf(TextFieldValue(value, selection = TextRange(value.length)))
    }
    if (textFieldValue.text != value) {
        textFieldValue = TextFieldValue(value, TextRange(value.length))
    }

    val keyboardController = LocalSoftwareKeyboardController.current

    val customTextSelectionColors = TextSelectionColors(
        handleColor = MaterialTheme.colorScheme.primary,
        backgroundColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
    )

    CompositionLocalProvider(LocalTextSelectionColors provides customTextSelectionColors) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    color = if (isFocused) MaterialTheme.colorScheme.primary else MaterialTheme.extendedColors.textInputBorderNormalColor,
                    shape = RoundedCornerShape(12.dp)
                )
                .pointerInput(Unit) {
                    detectTapGestures {
                        focusRequester.requestFocus()
                        keyboardController?.show()
                    }
                }
                .height(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(white)
                .padding(start = 12.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "+998",
                    color = secondaryTextColor2,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = 14.sp,
                        letterSpacing = 0.5.sp
                    ),
                    modifier = Modifier.padding(end = 4.dp)
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    BasicTextField(
                        value = textFieldValue,
                        onValueChange = { newValue ->
                            val digits = newValue.text.filter { it.isDigit() }.take(9)
                            val newSelection = newValue.selection.end.coerceIn(0, digits.length)
                            textFieldValue = TextFieldValue(digits, TextRange(newSelection))
                            onValueChange(digits)
                        },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .focusRequester(focusRequester)
                            .onFocusChanged {
                                isFocused = it.isFocused
                                onFocusChange(it.isFocused)
                            },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        decorationBox = { innerTextField ->
                            if (value.isEmpty()) {
                                Text(
                                    text = placeholder,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontSize = 14.sp,
                                        color = MaterialTheme.extendedColors.textInputLabelColor,
                                        letterSpacing = 0.45.sp
                                    )
                                )
                            }
                            innerTextField()
                        },
                        visualTransformation = PhoneNumberVisualTransformation()
                    )
                }
                if (value.length == 9) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_close),
                        contentDescription = "Clear",
                        tint = primaryTextColor,
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .size(40.dp)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                textFieldValue = TextFieldValue("")
                                onValueChange("")
                            }
                    )
                }
            }
        }
    }
}


class PhoneNumberVisualTransformation : VisualTransformation {
    private val spaceAfter = listOf(2, 5, 7)

    override fun filter(text: AnnotatedString): TransformedText {
        val digits = text.text.filter { it.isDigit() }.take(9)
        val out = StringBuilder()

        for (i in digits.indices) {
            out.append(digits[i])
            if (i + 1 in spaceAfter) out.append(' ')
        }

        val transformed = out.toString()

        val offsetMapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int {
                var count = 0
                for (i in 0 until offset) {
                    count++                       // digit
                    if (i + 1 in spaceAfter) count++ // space
                }
                return count
            }

            override fun transformedToOriginal(offset: Int): Int {
                var count = 0
                var transformedPos = 0
                while (transformedPos < offset && count < digits.length) {
                    transformedPos++ // digit
                    count++
                    if (count in spaceAfter) transformedPos++ // skip space
                }
                return count.coerceAtMost(digits.length)
            }
        }

        return TransformedText(AnnotatedString(transformed), offsetMapping)
    }
}

@Preview
@Composable
fun PhoneNumberTextFieldComponentPreview() {
    PaymeTheme {
        PhoneNumberTextFieldComponent(
            placeholder = "Enter your phone number",
            value = "",
            onValueChange = {},
            onFocusChange = {}
        )
    }
}