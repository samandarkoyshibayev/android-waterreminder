package com.android.presentation.feature.intro

interface IdentifyBenefitsScreenDirections {
}