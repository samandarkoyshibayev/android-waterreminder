package com.android.payme.ui.component

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.android.payme.ui.theme.PaymeTheme
import com.android.payme.ui.theme.appShapes
import com.android.payme.ui.theme.extendedColors

@Composable
fun OtpCodeComponent(
    modifier: Modifier = Modifier,
    errorState: String? = null,
    onErrorCleared: () -> Unit = {},
    onReadyListener: (String) -> Unit = {},
    onPinChange: (String) -> Unit = {}
) {
    val pinLength = 6
    var pin by remember { mutableStateOf(TextFieldValue("")) }
    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }
    CompositionLocalProvider(
        LocalTextSelectionColors provides TextSelectionColors(
            handleColor = Color.Transparent,
            backgroundColor = Color.Transparent
        )
    ) {
        BasicTextField(
            value = pin,
            onValueChange = { newValue ->
                val text = newValue.text
                if (text.length <= pinLength && (text.isEmpty() || text.all { it.isDigit() })) {
                    if (text.isEmpty()) {
                        onErrorCleared()
                    } else if (errorState != null && text.length < pin.text.length) {
                        onErrorCleared()
                    }

                    pin = newValue.copy(text = text, selection = TextRange(text.length))

                    onPinChange(text)

                    if (text.length == pinLength) {
                        onReadyListener(text)
                        keyboardController?.hide()
                    }
                }
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            textStyle = TextStyle(color = Color.Transparent),
            cursorBrush = SolidColor(Color.Transparent),
            modifier = modifier
                .focusRequester(focusRequester)
                .pointerInput(Unit) {
                    detectTapGestures {
                        focusRequester.requestFocus()
                    }
                },
            decorationBox = { innerTextField ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    repeat(pinLength) { index ->
                        val char = pin.text.getOrNull(index)?.toString() ?: ""
                        val isFocused = pin.text.length == index
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .border(
                                    width = 1.dp,
                                    color = when {
                                        errorState == "Correct OtpCode" -> MaterialTheme.colorScheme.primary
                                        errorState == "Incorrect OtpCode" -> MaterialTheme.extendedColors.textInputLabelColor
                                        index < pin.text.length -> MaterialTheme.colorScheme.primary // filled boxes stay primary
                                        pin.text.length == index -> MaterialTheme.colorScheme.primary // focused box
                                        else -> MaterialTheme.extendedColors.textInputBorderNormalColor
                                    },
                                    shape = MaterialTheme.appShapes.Large
                                )
                                .background(
                                    Color.White,
                                    shape = MaterialTheme.appShapes.Large
                                ),
                            contentAlignment = Alignment.Center
                        )
                        {
                            if (char.isNotEmpty()) {
                                Text(
                                    text = char,
                                    textAlign = TextAlign.Center,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        lineHeight = 22.sp, letterSpacing = 2.sp,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    ),
                                )
                            } else if (isFocused) {
                                Box(
                                    modifier = Modifier
                                        .width(2.dp)
                                        .size(width = 2.dp, height = 16.dp)
                                        .background(MaterialTheme.colorScheme.primary)
                                )
                            }
                        }
                    }
                }
                innerTextField()
            }
        )
    }
}

@Preview(showBackground = true)
@Composable
fun PinCodePreview() {
    PaymeTheme {
        OtpCodeComponent(errorState = null, onErrorCleared = {}, onReadyListener = {})
    }
}