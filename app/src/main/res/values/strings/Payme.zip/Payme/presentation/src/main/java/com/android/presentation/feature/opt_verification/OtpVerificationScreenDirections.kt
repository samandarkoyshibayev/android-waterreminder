package com.android.presentation.feature.opt_verification

interface OtpVerificationScreenDirections {
    suspend fun navigateToPinCodeScreen()
}