package com.android.payme.ui.component

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.android.payme.ui.theme.PaymeTheme
import com.android.payme.ui.theme.extendedColors
import com.android.payme.ui.theme.inter_semibold
import com.android.payme.ui.theme.white

@Composable
fun ConfirmButtonComponent(
    text: String,
    modifier: Modifier = Modifier,
    isEnable: Boolean = true,
    isLoading: Boolean = false,
    clickListener: () -> Unit,
) {

    val buttonColors = if (isLoading) {
        ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.secondaryContainer,
            disabledContainerColor = MaterialTheme.colorScheme.primary,
            disabledContentColor = MaterialTheme.colorScheme.secondaryContainer
        )
    } else {
        ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.extendedColors.buttonActiveBackgroundColor,
            contentColor = MaterialTheme.extendedColors.buttonActiveTextColor,
            disabledContainerColor = MaterialTheme.extendedColors.buttonInActiveBackgroundColor,
            disabledContentColor = MaterialTheme.extendedColors.buttonInActiveTextColor
        )
    }

    Button(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp),
        shape = RoundedCornerShape(12.dp),
        enabled = isEnable && !isLoading,
        colors = buttonColors,
        onClick = clickListener,
    ) {

        if (isLoading) {
            CircularProgressIndicator(
                color = MaterialTheme.colorScheme.secondaryContainer,
                strokeWidth = 2.dp,
                modifier = Modifier.size(24.dp)
            )
        } else {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontFamily = inter_semibold,
                    lineHeight = 22.sp,
                    letterSpacing = 0.20.sp
                ),
                color = if (isEnable) white else MaterialTheme.extendedColors.buttonInActiveTextColor
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ConfirmButtonComponentPreview() {
    PaymeTheme {
        ConfirmButtonComponent(
            isEnable = false,
            text = "Подтвердить",
            clickListener = {}
        )
    }
}