package com.android.payme.activity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import cafe.adriel.voyager.navigator.Navigator
import cafe.adriel.voyager.transitions.SlideTransition
import com.android.payme.presentation.splash.SplashScreen
import com.android.payme.ui.navigation.NavigationHandler
import com.android.payme.ui.theme.PaymeTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var navigationHandler: NavigationHandler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PaymeTheme {
                Navigator(screen = SplashScreen()) { navigator ->
                    LaunchedEffect(navigator) {
                        navigationHandler.screenState.collect { it(navigator) }
                    }
                    SlideTransition(navigator)
                }
            }
        }
    }
}