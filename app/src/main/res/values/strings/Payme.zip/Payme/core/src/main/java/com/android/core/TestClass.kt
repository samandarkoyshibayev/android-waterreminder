package com.android.core

class TestClass {
}