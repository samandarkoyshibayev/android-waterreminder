package com.android.presentation.feature.splash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SplashScreenViewModel @Inject constructor(
    private val splashScreenDirections: SplashScreenDirections
) : ViewModel(){
    init {
        viewModelScope.launch {
            delay(2000)
            splashScreenDirections.navigateToLoginScreen()
        }
    }
}