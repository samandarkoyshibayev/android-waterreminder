package com.android.payme.presentation.pincode

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.hilt.getViewModel
import com.android.payme.ui.theme.PaymeTheme
import com.android.payme.ui.theme.inter_semibold
import com.android.presentation.feature.opt_verification.OtpVerificationScreenViewModelContract
import com.android.presentation.feature.pincode.PinCodeScreenViewModel
import com.android.presentation.feature.pincode.PinCodeScreenViewModelContract
import org.orbitmvi.orbit.compose.collectAsState

class PINScreen : Screen {
    @Composable
    override fun Content() {
        val viewModel : PinCodeScreenViewModelContract.ViewModel = getViewModel<PinCodeScreenViewModel>()
        val uiState = viewModel.collectAsState().value
        PINScreenContent(
            uiState = uiState,
            onEventDispatcher =  viewModel::onEventDispatcher
        )
    }
}

@Composable
private fun PINScreenContent(
    uiState: PinCodeScreenViewModelContract.UIState,
    onEventDispatcher: (PinCodeScreenViewModelContract.Intent) -> Unit = {}
) {
    var pin by remember { mutableStateOf("") }

    val circleColor = Color(0xFFBDBDBD)
    val activeCircleColor = MaterialTheme.colorScheme.primary

    Scaffold() { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .background(Color(0xFFF5F5F5))
                .padding(horizontal = 16.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {

            Row(
                modifier = Modifier
                    .fillMaxWidth(),
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = MaterialTheme.colorScheme.onPrimary
                )
            }

            Column(
                modifier = Modifier.padding(top = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Create a PIN-code",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontFamily = inter_semibold
                    ),
                    modifier = Modifier.padding(bottom = 46.dp)
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(30.dp)
                ) {
                    repeat(4) { index ->
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .background(
                                    color = if (index < pin.length) activeCircleColor else circleColor,
                                    shape = CircleShape
                                )
                        )
                    }
                }
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 78.dp)
            ) {
                val keys = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("", "0", "⌫")
                )
                keys.forEach { row ->
                    Row(
                        horizontalArrangement = Arrangement.SpaceAround,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        row.forEach { key ->
                            when (key) {
                                "" -> Spacer(modifier = Modifier.size(50.dp))
                                "⌫" -> IconButton(
                                    onClick = {
                                        if (pin.isNotEmpty()) pin = pin.dropLast(1)
                                    },
                                    modifier = Modifier.size(50.dp)
                                ) {
                                     Icon(
                                         imageVector = Icons.Default.ArrowBack,
                                         contentDescription = "Delete",
                                         tint = Color(0xFF212121)
                                     )
                                }

                                else -> TextButton(
                                    onClick = {
                                        if (pin.length < 4) {
                                            pin += key
                                            if (pin.length == 4) {
                                                onEventDispatcher(PinCodeScreenViewModelContract.Intent.NavigateToIdentifyBenefitsScreen)
                                            }
                                        }
                                    },
                                    modifier = Modifier.size(50.dp)
                                ) {
                                    Text(
                                        text = key,
                                        style = MaterialTheme.typography.bodyLarge.copy(
                                            fontSize = 24.sp,
                                            color = MaterialTheme.colorScheme.onPrimary,
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/*
@Preview(showBackground = true)
@Composable
private fun CreatePINScreenContentPreview() {
    PaymeTheme {
        PINScreenContent() { }
    }
}*/
