package com.android.payme.presentation.splash

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.hilt.getViewModel
import com.android.payme.R
import com.android.payme.ui.theme.PaymeTheme
import com.android.presentation.feature.splash.SplashScreenViewModel

class SplashScreen : Screen {
    @Composable
    override fun Content() {
        val viewModel: SplashScreenViewModel = getViewModel()
        SplashScreenContent()
    }
}

@Composable
private fun SplashScreenContent() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(color = MaterialTheme.colorScheme.primary)
    ) {
        Image(
            modifier = Modifier
                .size(170.dp)
                .align(Alignment.Center),
            painter = painterResource(R.drawable.ic_payme_yellow),
            contentDescription = null
        )
    }
}

@Preview(showBackground = true)
@Composable
private fun SplashScreenContentPreview() {
    PaymeTheme {
        SplashScreenContent()
    }
}
