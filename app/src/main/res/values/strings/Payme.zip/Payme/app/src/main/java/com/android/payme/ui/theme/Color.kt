package com.android.payme.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import com.android.payme.R

val white = Color.White
val background = Color(0xFFF4F6F8)
val primaryTextColor = Color(0xFF273A4B)
val secondaryTextColor2 = Color(0xFF6E6D6D)

val LightPrimary = Color(0xFF2aced0)
val TextPrimary = Color(0xFF3f3f46)
val TextSecondary = Color(0xFF888894)
val TextInputLabelColor = Color(0xFFcdcdd2)
val TextInputBorderNormalColor = Color(0xffebedf0)
val TextRed = Color(0xfffa6a6a)
val ButtonInActiveBackgroundColor = Color(0xffe6f4f5)
val ButtonActiveBackgroundColor = Color(0xFF2aced0)
val ButtonInActiveTextColor = Color(0xffabebed)


data class ExtendedColors(
    val primary: Int,
    val textInputLabelColor: Color,
    val textInputBorderNormalColor: Color,
    val buttonInActiveBackgroundColor: Color,
    val buttonActiveBackgroundColor: Color,
    val buttonActiveTextColor: Color,
    val buttonInActiveTextColor: Color,
)

val LightExtendedColors = ExtendedColors(
    primary = R.color.primary_500,
    textInputLabelColor = TextInputLabelColor,
    buttonInActiveBackgroundColor = ButtonInActiveBackgroundColor,
    buttonActiveBackgroundColor = ButtonActiveBackgroundColor,
    buttonActiveTextColor = Color.White,
    buttonInActiveTextColor = ButtonInActiveTextColor,
    textInputBorderNormalColor = TextInputBorderNormalColor,
)

val DarkExtendedColors = ExtendedColors(
    primary = R.color.primary_500,
    textInputLabelColor = TextInputLabelColor,
    buttonInActiveBackgroundColor = ButtonInActiveBackgroundColor,
    buttonActiveBackgroundColor = ButtonActiveBackgroundColor,
    buttonActiveTextColor = Color.White,
    buttonInActiveTextColor = ButtonInActiveTextColor,
    textInputBorderNormalColor = TextInputBorderNormalColor,

)

internal val LightColorScheme = lightColorScheme(
    primary = LightPrimary,
    onPrimary = TextPrimary,
    onSecondary = TextSecondary,
    error = TextRed,
    background = background
)

internal val DarkColorScheme = darkColorScheme(
    primary = LightPrimary,
    onPrimary = TextPrimary,
    error = TextRed,
    onSecondary = TextSecondary,
    background = background


    )