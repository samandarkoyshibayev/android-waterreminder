package com.android.payme.presentation.login

import com.android.payme.presentation.otp_verification.OtpVerificationScreen
import com.android.payme.ui.navigation.AppNavigator
import com.android.presentation.feature.login.LoginScreenDirections
import com.android.presentation.feature.splash.SplashScreenDirections
import javax.inject.Inject

class LoginScreenDirectionsImpl @Inject constructor(
    private val appNavigator: AppNavigator
) : LoginScreenDirections {
    override suspend fun navigateToOTPVerification() {
        appNavigator.push(OtpVerificationScreen())
    }
}