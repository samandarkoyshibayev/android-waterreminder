package com.android.payme.presentation.login

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.Spring.StiffnessMedium
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.hilt.getViewModel
import com.android.payme.R
import com.android.payme.ui.component.ConfirmButtonComponent
import com.android.payme.ui.component.PhoneNumberTextFieldComponent
import com.android.payme.ui.theme.PaymeTheme
import com.android.payme.ui.theme.inter_semibold
import com.android.payme.ui.theme.secondaryTextColor2
import com.android.presentation.feature.login.LoginScreenViewModel
import com.android.presentation.feature.login.LoginScreenViewModelContract
import org.orbitmvi.orbit.compose.collectAsState
import kotlin.run

class LoginScreen : Screen {
    @Composable
    override fun Content() {
        val viewModel: LoginScreenViewModelContract.ViewModel = getViewModel<LoginScreenViewModel>()
        val uiState = viewModel.collectAsState().value
        LoginScreenContent(
            uiState = uiState,
            onEventDispatcher = viewModel::onEventDispatcher
        )
    }
}

@Composable
private fun LoginScreenContent(
    uiState: LoginScreenViewModelContract.UIState,
    onEventDispatcher: (LoginScreenViewModelContract.Intent) -> Unit = {}
) {
    var phoneNumber by remember { mutableStateOf("") }
    var labelColor by remember { mutableStateOf(true) }
    var selectedLanguage by remember { mutableStateOf("EN") }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            ConfirmButtonComponent(
                clickListener = { onEventDispatcher(LoginScreenViewModelContract.Intent.NavigateToOTPVerificationScreen) },
                text = when (selectedLanguage) {
                    "EN" -> "Continue"
                    "RU" -> "Продолжить"
                    "UZ" -> "Davom ettirish"
                    else -> "Continue"
                },
                isEnable = true,
                isLoading = false,
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .imePadding()
                    .navigationBarsPadding()
            )
        }
    ) { paddingValues ->
        Column(
            modifier =
                Modifier
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp)
        ) {
            LanguageSelector()

            Image(
                modifier = Modifier
                    .padding(top = 45.dp)
                    .size(110.dp),
                painter = painterResource(R.drawable.ic_payme),
                contentDescription = null,
                contentScale = ContentScale.Fit
            )

            Column(
                modifier = Modifier
                    .padding(top = 4.dp)
                    .fillMaxWidth()
                    .height(50.dp),
                verticalArrangement = Arrangement.SpaceBetween
            )
            {
                Text(
                    text = "Enter phone number",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontFamily = inter_semibold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                )
                Text(
                    text = "To login or register",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Normal,
                        color = MaterialTheme.colorScheme.onSecondary,
                        fontSize = 14.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(44.dp))

            Column(
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    modifier = Modifier.padding(start = 12.dp),
                    text = "Phone",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Normal,
                        color = if (labelColor) secondaryTextColor2 else MaterialTheme.colorScheme.primary,
                        fontSize = 12.sp
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                PhoneNumberTextFieldComponent(
                    placeholder = "Phone",
                    value = phoneNumber,
                    onValueChange = { newValue ->
                        phoneNumber = newValue
                    },
                    onFocusChange = { isFocused ->
                        labelColor = !isFocused
                    }
                )

                /* ErrorBanner(
                     "Internetda nosozlik\nIltimos, aloqani tekshirib, qaytadan urinib ko'ring",
                     modifier = Modifier.padding(top = 30.dp)
                 )*/

                Spacer(modifier = Modifier.weight(1f))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (!isKeyboardOpen()) {
                        ConsentText(
                            language = selectedLanguage,
                            modifier = Modifier,
                            onConsentClick = {
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ErrorBanner(
    message: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(
                color = Color(0xffffe8e8),
                shape = RoundedCornerShape(12.dp)
            )
            .padding(16.dp),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_error),
            contentDescription = "Warning",
            tint = Color(0xfffa6a6a),
            modifier = Modifier.size(20.dp)
        )

        Spacer(modifier = Modifier.width(16.dp))

        Text(
            text = message,
            style = MaterialTheme.typography.bodyLarge.copy(
                fontSize = 14.sp,
                lineHeight = 20.sp,
                color = Color(0xfffa6a6a)

            )
        )
    }
}

@Composable
private fun isKeyboardOpen(): Boolean {
    val ime = WindowInsets.ime
    val density = LocalDensity.current

    val imeBottom = ime.getBottom(density)
    return imeBottom > 0
}

@Composable
private fun LanguageSelector(
    modifier: Modifier = Modifier,
    initialLanguage: String = "EN"
) {
    var isExpanded by remember { mutableStateOf(false) }
    var selectedLanguage by remember { mutableStateOf(initialLanguage) }
    var selectedFlag by remember {
        mutableStateOf(
            when (initialLanguage) {
                "EN" -> R.drawable.ic_en
                "RU" -> R.drawable.ic_ru
                else -> R.drawable.ic_uz
            }
        )
    }

    val allLanguages = listOf(
        "EN" to R.drawable.ic_en,
        "UZ" to R.drawable.ic_uz,
        "RU" to R.drawable.ic_ru
    )

    val displayLanguages = remember(selectedLanguage) {
        val selected = allLanguages.first { it.first == selectedLanguage }
        val others = allLanguages.filter { it.first != selectedLanguage }
        listOf(selected) + others
    }

    // Animation values
    val expandProgress by animateFloatAsState(
        targetValue = if (isExpanded) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "expand"
    )

    val scale by animateFloatAsState(
        targetValue = if (isExpanded) 1f else 0.8f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = StiffnessMedium
        ),
        label = "scale"
    )

    Box(
        modifier = modifier
            .padding(top = 16.dp)
            .fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .width(78.dp)
        ) {
            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn(animationSpec = tween(200)) +
                        scaleIn(
                            initialScale = 0.8f,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                stiffness = StiffnessMedium
                            )
                        ),
                exit = fadeOut(animationSpec = tween(150)) +
                        scaleOut(
                            targetScale = 0.8f,
                            animationSpec = tween(150)
                        )
            ) {
                Column(
                    modifier = Modifier
                        .background(color = Color.White, RoundedCornerShape(8.dp))
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    displayLanguages.forEachIndexed { index, (lang, flag) ->
                        val itemScale by animateFloatAsState(
                            targetValue = if (isExpanded) 1f else 0.8f,
                            label = "itemScale$index"
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(36.dp)
                                .graphicsLayer {
                                    scaleX = itemScale
                                    scaleY = itemScale
                                    alpha = itemScale
                                }
                                .clickable {
                                    if (lang != selectedLanguage) {
                                        selectedLanguage = lang
                                        selectedFlag = flag
                                    }
                                    isExpanded = false
                                }
                                .padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Text(
                                text = lang,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                            Image(
                                modifier = Modifier.size(26.dp),
                                painter = painterResource(flag),
                                contentDescription = null
                            )
                        }
                    }
                }
            }

            if (!isExpanded) {
                Row(
                    modifier = Modifier
                        .size(height = 36.dp, width = 78.dp)
                        .background(color = Color.White, RoundedCornerShape(8.dp))
                        .clickable { isExpanded = true }
                        .padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Text(
                        text = selectedLanguage,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                    Image(
                        modifier = Modifier.size(26.dp),
                        painter = painterResource(selectedFlag),
                        contentDescription = null
                    )
                }
            }
        }
    }
}
@Composable
private fun ConsentText(
    language: String,
    modifier: Modifier = Modifier,
    onConsentClick: () -> Unit = {}
) {
    val annotatedString = when (language) {
        "EN" -> buildAnnotatedString {
            withStyle(style = androidx.compose.ui.text.SpanStyle(color = Color.Black)) {
                append("By pressing the \"Continue\", I provide my ")
            }
            pushStringAnnotation(tag = "consent", annotation = "consent_link")
            withStyle(
                style = androidx.compose.ui.text.SpanStyle(
                    MaterialTheme.colorScheme.primary
                )
            ) {
                append("Consent to data processing")
            }
            pop()
        }

        "RU" -> buildAnnotatedString {
            withStyle(style = androidx.compose.ui.text.SpanStyle(color = Color.Black)) {
                append("Нажимая \"Продолжить\", я даю свое ")
            }
            pushStringAnnotation(tag = "consent", annotation = "consent_link")
            withStyle(
                style = androidx.compose.ui.text.SpanStyle(
                    MaterialTheme.colorScheme.primary

                )
            ) {
                append("Согласие на обработку данных")
            }
            pop()
        }

        "UZ" -> buildAnnotatedString {
            withStyle(style = androidx.compose.ui.text.SpanStyle(color = Color.Black)) {
                append("\"Davom ettirish\" tugmasini bosgan holda, men ")
            }
            pushStringAnnotation(tag = "consent", annotation = "consent_link")
            withStyle(
                style = androidx.compose.ui.text.SpanStyle(
                    MaterialTheme.colorScheme.primary
                )
            ) {
                append("Ma'lumotlarni qayta ishlashga rozlik")
            }
            pop()
            withStyle(style = androidx.compose.ui.text.SpanStyle(color = Color.Black)) {
                append(" beraman")
            }
        }

        else -> buildAnnotatedString {
            append("Consent text not available")
        }
    }

    androidx.compose.foundation.text.ClickableText(
        text = annotatedString,
        modifier = modifier,
        style = MaterialTheme.typography.bodySmall.copy(
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
            lineHeight = 16.sp
        ),
        onClick = { offset ->
            annotatedString.getStringAnnotations(
                tag = "consent",
                start = offset,
                end = offset
            ).firstOrNull()?.let {
                onConsentClick()
            }
        }
    )
}

@Preview(showBackground = true)
@Composable
private fun LoginScreenContentPreview() {
    PaymeTheme {
        LoginScreenContent(
            uiState = LoginScreenViewModelContract.UIState()
        )
    }
}
