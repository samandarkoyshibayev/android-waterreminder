package com.android.presentation.feature.pincode

interface PINCodeScreenDirections {
    suspend fun navigateToIdentifyBenefitsScreen()
}