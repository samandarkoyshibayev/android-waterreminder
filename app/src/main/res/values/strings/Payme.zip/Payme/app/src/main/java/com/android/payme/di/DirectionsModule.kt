package com.android.payme.di

import com.android.payme.presentation.login.LoginScreenDirectionsImpl
import com.android.payme.presentation.otp_verification.OtpVerificationScreenDirectionsImpl
import com.android.payme.presentation.pincode.PINCodeScreenDirectionsImpl
import com.android.payme.presentation.splash.SplashScreenDirectionsImpl
import com.android.presentation.feature.login.LoginScreenDirections
import com.android.presentation.feature.opt_verification.OtpVerificationScreenDirections
import com.android.presentation.feature.pincode.PINCodeScreenDirections
import com.android.presentation.feature.splash.SplashScreenDirections
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
interface DirectionsModule {

    @Binds
    fun provideSplashScreenDirections(impl: SplashScreenDirectionsImpl): SplashScreenDirections

    @Binds
    fun provideLoginScreenDirections(impl: LoginScreenDirectionsImpl): LoginScreenDirections

    @Binds
    fun provideOtpVerificationScreenDirections(impl: OtpVerificationScreenDirectionsImpl) : OtpVerificationScreenDirections

    @Binds
    fun providePINCodeScreenDirections(impl: PINCodeScreenDirectionsImpl): PINCodeScreenDirections
}