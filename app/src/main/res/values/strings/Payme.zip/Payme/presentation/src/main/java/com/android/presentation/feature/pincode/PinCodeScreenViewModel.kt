package com.android.presentation.feature.pincode

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import org.orbitmvi.orbit.viewmodel.container
import javax.inject.Inject

@HiltViewModel
class PinCodeScreenViewModel @Inject constructor(
    private val pinCodeScreenDirections: PINCodeScreenDirections
) : PinCodeScreenViewModelContract.ViewModel, ViewModel() {

    override fun onEventDispatcher(intent: PinCodeScreenViewModelContract.Intent) {
        when (intent) {
            is PinCodeScreenViewModelContract.Intent.NavigateToIdentifyBenefitsScreen -> {
                intent {
                    pinCodeScreenDirections.navigateToIdentifyBenefitsScreen()
                }
            }
        }
    }

    override val container =
        container<PinCodeScreenViewModelContract.UIState, PinCodeScreenViewModelContract.SideEffect>(
            PinCodeScreenViewModelContract.UIState()
        )

}