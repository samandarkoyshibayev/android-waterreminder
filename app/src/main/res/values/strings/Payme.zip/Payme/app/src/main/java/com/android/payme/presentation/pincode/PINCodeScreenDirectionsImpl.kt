package com.android.payme.presentation.pincode

import com.android.payme.presentation.intro.IdentifyBenefitsScreen
import com.android.payme.ui.navigation.AppNavigator
import com.android.presentation.feature.pincode.PINCodeScreenDirections
import javax.inject.Inject

class PINCodeScreenDirectionsImpl @Inject constructor(
    private val appNavigator: AppNavigator
) : PINCodeScreenDirections{
    override suspend fun navigateToIdentifyBenefitsScreen() {
        appNavigator.replace(IdentifyBenefitsScreen())
    }
}