package com.android.presentation.feature.pincode

import org.orbitmvi.orbit.ContainerHost

interface PinCodeScreenViewModelContract {

    interface ViewModel : ContainerHost<UIState, SideEffect> {
        fun onEventDispatcher(intent: Intent)
    }

    data class UIState(
        val temp: String = ""
    )

    interface SideEffect {}

    interface Intent {
        object NavigateToIdentifyBenefitsScreen : Intent
    }
}