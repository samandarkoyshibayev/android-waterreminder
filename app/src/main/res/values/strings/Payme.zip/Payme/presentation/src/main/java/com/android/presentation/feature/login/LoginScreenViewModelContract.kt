package com.android.presentation.feature.login

import android.content.Intent
import org.orbitmvi.orbit.ContainerHost

interface LoginScreenViewModelContract {

    interface ViewModel : ContainerHost<UIState, SideEffect> {
        fun onEventDispatcher(intent: Intent)
    }

    data class UIState(
        val temp: String = ""
    )

    interface SideEffect {}

    interface Intent {
        object NavigateToOTPVerificationScreen : Intent
    }

}