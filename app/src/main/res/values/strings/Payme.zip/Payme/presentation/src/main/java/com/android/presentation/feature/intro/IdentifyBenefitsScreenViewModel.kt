package com.android.presentation.feature.intro

class IdentifyBenefitsScreenViewModel {
}