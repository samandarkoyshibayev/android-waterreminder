package com.android.payme.di

import com.android.payme.ui.navigation.AppNavigationDispatcher
import com.android.payme.ui.navigation.AppNavigator
import com.android.payme.ui.navigation.NavigationHandler
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
interface NavigationModule {
    @Binds
    fun provideAppNavigator(impl: AppNavigationDispatcher): AppNavigator

    @Binds
    fun navigationHandler(impl: AppNavigationDispatcher): NavigationHandler
}