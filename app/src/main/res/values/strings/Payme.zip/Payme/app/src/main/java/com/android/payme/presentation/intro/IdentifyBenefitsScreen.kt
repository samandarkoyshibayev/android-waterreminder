package com.android.payme.presentation.intro

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cafe.adriel.voyager.core.screen.Screen
import com.android.payme.R
import com.android.payme.ui.theme.PaymeTheme
import com.android.payme.ui.theme.inter_bold

class IdentifyBenefitsScreen : Screen {
    @Composable
    override fun Content() {
        IdentifyBenefitsScreenContent()
    }
}

@Composable
private fun IdentifyBenefitsScreenContent() {
    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    listOf(Color(0xFFF8F9FB), Color(0xFFE9F5FF))
                )
            )
    ) {
        BackgroundBlurEffect()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Box(
                modifier = Modifier.fillMaxWidth()
            ){Text(
                text = "Verify your identity\nand enjoy these \nbenefits",
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = inter_bold,
                    color = Color(0xFF1C1C1E),
                    fontSize = 24.sp,
                    lineHeight = 30.sp
                ),
                modifier = Modifier.padding(top = 20.dp, bottom = 10.dp)
            )}

            Box(modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(R.drawable.img_cashback1),
                    contentDescription = null,
                    modifier = Modifier
                        .size(190.dp)
                        .align(Alignment.TopStart)
                        .offset(x = 0.dp, y = 0.dp)
                )
                Image(
                    painter = painterResource(R.drawable.img_cashback0),
                    contentDescription = null,
                    modifier = Modifier
                        .size(190.dp)
                        .align(Alignment.TopEnd)
                        .offset(x = (10).dp, y = 40.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(R.drawable.img_flight_tickets),
                    contentDescription = null,
                    modifier = Modifier
                        .size(180.dp)
                        .align(Alignment.TopStart)
                )
                Image(
                    painter = painterResource(R.drawable.img_payme_plus),
                    contentDescription = null,
                    modifier = Modifier
                        .size(150.dp)
                        .align(Alignment.TopEnd)
                        .offset(x= (-20).dp, y = 20.dp)
                )
            }

            Box(modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(R.drawable.img_cash_flow),
                    contentDescription = null,
                    modifier = Modifier
                        .size(170.dp)
                        .align(Alignment.TopStart)
                        .offset(x = 0.dp, y = 0.dp)
                )
                Image(
                    painter = painterResource(R.drawable.img_statements3),
                    contentDescription = null,
                    modifier = Modifier
                        .size(200.dp)
                        .align(Alignment.TopEnd)
                        .offset(x = (0).dp, y = (-10).dp)
                )
            }

            Box(modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(R.drawable.img_movie_tickets),
                    contentDescription = null,
                    modifier = Modifier
                        .size(190.dp)
                        .align(Alignment.TopStart)
                        .offset(x = (0).dp, y = (-40).dp)

                )
                Image(
                    painter = painterResource(R.drawable.img_payment_deferral),
                    contentDescription = null,
                    modifier = Modifier
                        .size(170.dp)
                        .align(Alignment.TopEnd)
                        .offset(y = (-20).dp)
                )
            }

            Box(modifier = Modifier.padding(bottom = 60.dp).fillMaxWidth()) {
                Image(
                    painter = painterResource(R.drawable.img_phone_payment),
                    contentDescription = null,
                    modifier = Modifier
                        .size(140.dp)
                        .align(Alignment.TopStart)
                        .offset(x = (-10).dp, y = (-60).dp)

                )
                Image(
                    painter = painterResource(R.drawable.img_utility_bill),
                    contentDescription = null,
                    modifier = Modifier
                        .size(160.dp)
                        .align(Alignment.TopEnd)
                        .offset(y = (-50).dp, x = (-70).dp,)
                )
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background.copy(alpha = 0f),
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
                .padding(horizontal = 16.dp)
                .padding(bottom = 20.dp)
                .navigationBarsPadding()
        ) {
            Button(
                onClick = {
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent
                )
                ,
                contentPadding = PaddingValues(0.dp)

            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Verify identity",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun IdentifyBenefitsScreenPreview() {
    PaymeTheme {
        IdentifyBenefitsScreenContent()
    }
}

@Composable
private fun BackgroundBlurEffect() {
    val blueTeal = listOf(
        Color(0xFF00BCD4).copy(alpha = 0.5f),
        Color(0xFF2196F3).copy(alpha = 0.4f),
        Color.Transparent
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.radialGradient(
                        colors = blueTeal,
                        center = androidx.compose.ui.geometry.Offset(
                            x = 500f,
                            y = 1200f
                        ),
                        radius = 900f
                    )
                )
        )
    }
}
