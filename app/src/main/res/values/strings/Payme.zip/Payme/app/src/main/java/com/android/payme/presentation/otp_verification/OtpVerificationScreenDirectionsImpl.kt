package com.android.payme.presentation.otp_verification

import com.android.payme.presentation.pincode.PINScreen
import com.android.payme.ui.navigation.AppNavigator
import com.android.presentation.feature.opt_verification.OtpVerificationScreenDirections
import javax.inject.Inject

class OtpVerificationScreenDirectionsImpl @Inject constructor(
    private val appNavigator: AppNavigator
): OtpVerificationScreenDirections {
    override suspend fun navigateToPinCodeScreen() {
        appNavigator.push(PINScreen())
    }
}