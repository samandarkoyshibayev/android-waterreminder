package com.android.presentation.feature.opt_verification

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import org.orbitmvi.orbit.viewmodel.container
import javax.inject.Inject

@HiltViewModel
class OtpVerificationScreenViewModel @Inject constructor(
    private val otpVerificationScreenDirections: OtpVerificationScreenDirections
) : OtpVerificationScreenViewModelContract.ViewModel, ViewModel() {

    override fun onEventDispatcher(intent: OtpVerificationScreenViewModelContract.Intent) {
        when (intent) {
            is OtpVerificationScreenViewModelContract.Intent.NavigateToPinCodeScreen -> {
                intent {
                    otpVerificationScreenDirections.navigateToPinCodeScreen()
                }
            }
        }
    }

    override val container =
        container<OtpVerificationScreenViewModelContract.UIState, OtpVerificationScreenViewModelContract.SideEffect>(
            OtpVerificationScreenViewModelContract.UIState()
        )

}