package com.android.presentation.feature.login

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import org.orbitmvi.orbit.viewmodel.container
import javax.inject.Inject

@HiltViewModel
class LoginScreenViewModel @Inject constructor(
    private val loginScreenDirections: LoginScreenDirections
) : LoginScreenViewModelContract.ViewModel,
    ViewModel() {

    override val container =
        container<LoginScreenViewModelContract.UIState, LoginScreenViewModelContract.SideEffect>(
            LoginScreenViewModelContract.UIState()
        )

    override fun onEventDispatcher(intent: LoginScreenViewModelContract.Intent) {
        when (intent) {
            is LoginScreenViewModelContract.Intent.NavigateToOTPVerificationScreen -> {
                intent {
                    loginScreenDirections.navigateToOTPVerification()
                }
            }
        }
    }
}