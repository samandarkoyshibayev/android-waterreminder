package com.android.presentation.feature.opt_verification

import org.orbitmvi.orbit.ContainerHost

interface OtpVerificationScreenViewModelContract {

    interface ViewModel : ContainerHost<UIState, SideEffect> {
        fun onEventDispatcher(intent: Intent)
    }

    data class UIState(
        val temp: String = ""
    )

    interface SideEffect {}

    interface Intent {
        object NavigateToPinCodeScreen : Intent
    }
}