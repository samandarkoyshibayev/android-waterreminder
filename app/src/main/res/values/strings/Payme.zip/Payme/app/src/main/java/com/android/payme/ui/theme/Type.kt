package com.android.payme.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.android.payme.R

private val roboto = FontFamily(
    Font(R.font.roboto, FontWeight.Normal),
)

val inter = FontFamily(
    Font(R.font.inter, FontWeight.Normal),
)

val inter_bold = FontFamily(
    Font(R.font.inter_bold, FontWeight.Bold),
)
val inter_semibold = FontFamily(
    Font(R.font.inter_semibold, FontWeight.SemiBold),
)

val poppins = FontFamily(
    Font(R.font.poppins_regular, FontWeight.Normal),
)
val nunito = FontFamily(
    Font(R.font.nunito, FontWeight.Normal),
)


val Typography = Typography(
    bodyLarge = TextStyle(
        fontFamily = inter,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 0.sp,
        letterSpacing = 0.0.sp,
    )
)