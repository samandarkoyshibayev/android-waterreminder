package com.android.waterreminder.presentation.screens.onboarding

interface OnboardingDirections {
    suspend fun navigateToBodyInfoScreen()
}