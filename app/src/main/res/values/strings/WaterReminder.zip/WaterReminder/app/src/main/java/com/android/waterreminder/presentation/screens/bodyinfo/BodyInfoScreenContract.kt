package com.android.waterreminder.presentation.screens.bodyinfo

interface BodyInfoScreenContract {
}