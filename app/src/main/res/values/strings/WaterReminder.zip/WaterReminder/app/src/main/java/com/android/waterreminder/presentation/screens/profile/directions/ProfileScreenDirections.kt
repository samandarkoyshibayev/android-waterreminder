package com.android.waterreminder.presentation.screens.profile.directions

interface ProfileScreenDirections {
    suspend fun navigateToEditScreen()
}