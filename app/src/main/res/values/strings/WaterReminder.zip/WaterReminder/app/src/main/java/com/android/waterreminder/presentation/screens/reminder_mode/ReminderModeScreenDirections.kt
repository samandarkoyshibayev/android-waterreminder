package com.android.waterreminder.presentation.screens.reminder_mode

interface ReminderModeScreenDirections {

    suspend fun back()
}