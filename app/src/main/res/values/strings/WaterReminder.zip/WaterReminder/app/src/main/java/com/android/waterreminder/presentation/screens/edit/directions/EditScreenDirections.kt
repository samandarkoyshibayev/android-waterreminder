package com.android.waterreminder.presentation.screens.edit.directions

interface EditScreenDirections {
    suspend fun back()
}