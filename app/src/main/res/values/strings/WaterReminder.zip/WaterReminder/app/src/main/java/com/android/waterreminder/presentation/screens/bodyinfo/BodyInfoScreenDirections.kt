package com.android.waterreminder.presentation.screens.bodyinfo

interface BodyInfoScreenDirections {
    suspend fun navigateToMainScreen()
}