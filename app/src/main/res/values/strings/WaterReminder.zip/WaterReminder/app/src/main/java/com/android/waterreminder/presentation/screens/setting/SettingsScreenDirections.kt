package com.android.waterreminder.presentation.screens.setting

interface SettingsScreenDirections {
    suspend fun navigateToReminderModeScreen()
}